class Person {
    constructor(name, age, country){
        this.name= name; 
        this.age= age; 
        this.country= country; 
    }
    displayDetails(){
        console.log(`Name: ${this.name}`);
        console.log(`Age: ${this.age}`);
        console.log(`Country: ${this.country}`);
        console.log(`Birthplace: ${this.birthplace}`);
        console.log(``);
    }
}

const Person1 = new Person (`Rico Galang`,25,`Australia`,`Manila`);
const Person2 = new Person (`Richard Topaz`,40,`Netherlands`,`Sucat`);
const Person3 = new Person (`Pia lim`,33,`Singapore`,`Rizal`);
const Person4 = new Person (`Pochie Abe`,26,`Switzerland`,`Bicol`);

console.log(`Person1 Details: `);
Person1.displayDetails();

console.log(`Person2 Details: `);
Person2.displayDetails();

console.log(`Person3 Details: `);
Person3.displayDetails();

console.log(`Person3 Details: `);
Person4.displayDetails();
