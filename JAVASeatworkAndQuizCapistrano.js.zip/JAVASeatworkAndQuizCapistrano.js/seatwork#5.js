var number=10;
if (number% 2===0){
    {console.log("It is even number")}
}else{console.log("it is odd");

}