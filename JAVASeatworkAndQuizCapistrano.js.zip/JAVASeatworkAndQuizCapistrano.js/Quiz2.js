// sample of input
var number=2;

//conditon
if (number>0){

    //out put
    {console.log("num2 is greater")}
}
else{console.log("num2 is less");

}