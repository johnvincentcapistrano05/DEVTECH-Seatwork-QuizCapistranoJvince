class Vehicle {
    constructor(make, model, year, Ownername, door){
        this.make= make; 
        this.model= model; 
        this.year= year; 
        this.Ownername= Ownername;
        this.door= door; 
    }
    displayDetails(){
        console.log(`Make: ${this.make}`);
        console.log(`model: ${this.model}`);
        console.log(`year: ${this.year}`);
        console.log(`Ownername: ${this.Ownername}`);
        console.log(``);
    }

    displayDetails2(){
        console.log(`Make: ${this.make}`);
        console.log(`model: ${this.model}`);
        console.log(`year: ${this.year}`);
        console.log(`Ownername: ${this.Ownername}`);
        console.log(`Door: ${this.door}`);
        console.log(``);
    }
}

const car1 = new  Vehicle (`Ford`,`F-150`,2020,`Joshua`,``);
const car2 = new Vehicle (`honda`,`accord`,2023,`Rica`,4);

console.log(`Vehicle Details: `);
car1.displayDetails();

console.log(`Car Details: `);
car2.displayDetails2();