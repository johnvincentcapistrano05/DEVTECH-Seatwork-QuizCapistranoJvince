// sample of input
var number=8;

//conditon
if (number% 2===0){

    //out put
    {console.log("It is even number")}
}else{console.log("it is odd");

}