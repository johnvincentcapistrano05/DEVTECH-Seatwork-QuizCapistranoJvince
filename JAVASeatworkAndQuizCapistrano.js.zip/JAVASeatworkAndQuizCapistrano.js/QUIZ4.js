
class Vehicle {
    constructor(name, model, weight, color2 ){
        this.name= name; 
        this.model= model; 
        this.weight= weight; 
        this.color2= color2;
    }
    displayDetails(){
        console.log(`Name: ${this.name}`);
        console.log(`model: ${this.model}`);
        console.log(`Weight: ${this.weight}klg`);
        console.log(`Color: ${this.color2}`);
    }
}
        const car1 = new  Vehicle (`Honda`,`Mobilio`,300,`White`);
        const car2 = new Vehicle (`Toyota`,`Fortuner`,400 ,`Blue`);

        console.log(`Vehicle - 1 Details: `);
        car1.displayDetails();

        console.log(`Vehicle - 2 Details: `);
        car2.displayDetails();
    
